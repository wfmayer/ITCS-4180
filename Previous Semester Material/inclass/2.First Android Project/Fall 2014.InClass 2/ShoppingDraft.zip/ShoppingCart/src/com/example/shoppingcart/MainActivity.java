package com.example.shoppingcart;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View.OnClickListener;

public class MainActivity extends ActionBarActivity {

	double total;
	TextView cartItems, totalTxt;
	ImageView item1, item2, item3;
	Button addApple, addBanana, addBread, addEggs, clear;

	//int PRICE, ID;

	protected void bindUI() {

		cartItems = (TextView) findViewById(R.id.textView1);
		totalTxt = (TextView) findViewById(R.id.textView2);

		item1 = (ImageView) findViewById(R.id.ImageView02);
		item2 = (ImageView) findViewById(R.id.ImageView01);
		item3 = (ImageView) findViewById(R.id.imageView1);
		
		item1.setTag(R.drawable.empty);
		item2.setTag(R.drawable.empty);
		item3.setTag(R.drawable.empty);

		addApple = (Button) findViewById(R.id.button1);
		//addApple.setTag(addApple.getId(), 0.75);
		//addApple.setTag(addApple.getId(), R.drawable.empty);
//
		addBanana = (Button) findViewById(R.id.button2);
//		addBanana.setTag(PRICE, 0.50);
//		addBanana.setTag(ID, R.drawable.empty);
//
		addBread = (Button) findViewById(R.id.button3);
//		addBread.setTag(PRICE, 2.25);
//		addBread.setTag(ID, R.drawable.empty);
//
		addEggs = (Button) findViewById(R.id.button4);
//		addEggs.setTag(PRICE, 3.25);
//		addEggs.setTag(ID, R.drawable.empty);
//
	//checkOut = (Button) findViewById(R.id.button6);
//
		clear = (Button) findViewById(R.id.button7);

	}

	protected ImageView getEmptyItem() {
		if (Integer.parseInt(item1.getTag().toString()) == R.drawable.empty)
			return item1;
		if (Integer.parseInt(item2.getTag().toString()) == R.drawable.empty)
			return item2;
		if (Integer.parseInt(item3.getTag().toString()) == R.drawable.empty)
			return item3;
		return null;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		bindUI();
		total = 0;
//
		addApple.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ImageView currentItem = getEmptyItem();
				if (currentItem != null) {
					currentItem.setImageResource(R.drawable.apple);
					currentItem.setTag(R.drawable.apple);
					total += 0.85;
					totalTxt.setText("Total :$" + total);
				} else {

				}
			}
		});
//
		addBanana.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ImageView currentItem = getEmptyItem();
				if (currentItem != null) {
					currentItem.setImageResource(R.drawable.banana);
					currentItem.setTag(R.drawable.banana);
					total += 0.25;
					totalTxt.setText("Total :$" + total);
				} else {

				}
			}
		});
		addBread.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ImageView currentItem = getEmptyItem();
				if (currentItem != null) {
					currentItem.setImageResource(R.drawable.bread);
					currentItem.setTag(R.drawable.bread);
					total += 1.25;
					totalTxt.setText("Total :$" + total);
				} else {

				}
			}
		});
		addEggs.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("D", "in button4") ;
				// TODO Auto-generated method stub
				ImageView currentItem = getEmptyItem();
				if (currentItem != null) {
					currentItem.setImageResource(R.drawable.egg);
					currentItem.setTag(R.drawable.egg);
					total += 2.5;
					totalTxt.setText("Total :$" + total);
				} else {

				}
			}
		});

		clear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				total= 0;
				item1.setImageResource(R.drawable.empty);
				item1.setTag(R.drawable.empty);
				item2.setImageResource(R.drawable.empty);
				item2.setTag(R.drawable.empty);
				item3.setImageResource(R.drawable.empty);
				item3.setTag(R.drawable.empty);
				totalTxt.setText("Total :$" + total);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

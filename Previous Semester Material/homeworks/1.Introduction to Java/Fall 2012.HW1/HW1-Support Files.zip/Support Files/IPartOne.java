public interface IPartOne {
    public void analyseCountriesFile(String filePath);
    public void printCollectedStats();
}
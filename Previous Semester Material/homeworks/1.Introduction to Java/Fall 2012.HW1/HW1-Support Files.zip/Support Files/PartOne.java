public class PartOne implements IPartOne{
	//Should implment the IPartOne interface
	
}

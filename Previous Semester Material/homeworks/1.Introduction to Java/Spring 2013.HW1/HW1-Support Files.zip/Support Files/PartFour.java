
public class PartFour {
	public static void main(String[] args) {
		// Include implementation for Part 4, and create all the required classes.
	}

}

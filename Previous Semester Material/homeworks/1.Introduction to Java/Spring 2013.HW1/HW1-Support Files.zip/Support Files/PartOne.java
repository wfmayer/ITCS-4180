public class PartOne {
	public static void main(String[] args) {
		// Include implementation for Part 1, and create all the required classes.
	}
}
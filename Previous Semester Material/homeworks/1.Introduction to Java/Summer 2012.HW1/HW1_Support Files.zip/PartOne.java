public class PartOne implements IPartOne {
	
}

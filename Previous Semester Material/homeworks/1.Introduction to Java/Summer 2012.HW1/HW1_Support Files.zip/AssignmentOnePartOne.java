public class AssignmentOnePartOne {
	public static void main(String[] args) {
	    PartOne p = new PartOne();
	    p.analyseCountriesFile("countries.txt");
	    p.printCollectedStats();
	}
}

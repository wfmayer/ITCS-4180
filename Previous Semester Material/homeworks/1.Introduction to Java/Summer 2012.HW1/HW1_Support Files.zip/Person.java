
public class Person {
private String id;
private String name;
private int age;

public Person(String newId, String newName, int newAge){
	id = newId;
	name = newName;
	age = newAge;	
}
public String getId(){
	return id;
}

public String getName(){
	return name;
}

public int getAge(){
	return age;
}

public void setId(String newId){
	id = newId;
}

public void setName(String newName){
	name = newName;
}

public void setAge(int newAge){
	age = newAge;
}


}

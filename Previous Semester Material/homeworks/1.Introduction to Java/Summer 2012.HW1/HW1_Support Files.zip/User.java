
public class User extends Person {

	
}

The included photos should be used in the app, their description is as follows:

app_logo.png, this should be used for your app logo. 
certified_fresh.png, this should be used to represent a "Certified Fresh" movie rating.
fresh.png,this should be used to represent a "Fresh" movie rating.
notranked.png, this should be used to represent a not ranked movie rating.
poster_not_found.png, this should be used if the movie poster is not found.
rotten.png, this should be used to represent a "Rotten" movie rating.
spilled.png, this should be used to represent a "Spilled" movie rating.
upright.png, this should be used to represent a "Upright" movie rating.

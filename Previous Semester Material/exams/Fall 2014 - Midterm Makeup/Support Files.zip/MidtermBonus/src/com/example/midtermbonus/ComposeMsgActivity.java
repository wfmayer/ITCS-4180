package com.example.midtermbonus;

import android.app.Activity;
import android.os.Bundle;

public class ComposeMsgActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_compose_msg);
	}
	
}

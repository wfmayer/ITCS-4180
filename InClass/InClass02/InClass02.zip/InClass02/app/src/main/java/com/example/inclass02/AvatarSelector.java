package com.example.inclass02;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

public class AvatarSelector extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar_selector);

        final ImageButton imageButton1 = findViewById(R.id.imageButton1);
        final ImageButton imageButton2 = findViewById(R.id.imageButton2);
        final ImageButton imageButton3 = findViewById(R.id.imageButton3);
        final ImageButton imageButton4 = findViewById(R.id.imageButton4);
        final ImageButton imageButton5 = findViewById(R.id.imageButton5);
        final ImageButton imageButton6 = findViewById(R.id.imageButton6);

        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton1.getDrawable();
                if (resource == null) {
                    Log.d("demo", "TEST ON NULL");
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_f1");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton2.getDrawable();
                if (resource == null) {
                    Log.d("demo", "TEST ON NULL");
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_m1");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton3.getDrawable();
                if (resource == null) {
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_f2");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });

        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton4.getDrawable();
                if (resource == null) {
                    Log.d("demo", "TEST ON NULL");
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_m2");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });

        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton5.getDrawable();
                if (resource == null) {
                    Log.d("demo", "TEST ON NULL");
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_f3");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });

        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drawable resource = imageButton6.getDrawable();
                if (resource == null) {
                    Log.d("demo", "TEST ON NULL");
                    setResult(RESULT_CANCELED);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY, "av_m3");
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        });
    }
}

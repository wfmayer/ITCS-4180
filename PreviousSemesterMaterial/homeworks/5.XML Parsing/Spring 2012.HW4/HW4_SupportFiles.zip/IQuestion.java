import java.util.ArrayList;

abstract class IQuestion {

	String id, text, imageURL;
	ArrayList<String> answerOptions;
	int correctAnswerIndex;
	
	abstract int getNumberOfAnswerOption();
	abstract boolean hasImage();
}

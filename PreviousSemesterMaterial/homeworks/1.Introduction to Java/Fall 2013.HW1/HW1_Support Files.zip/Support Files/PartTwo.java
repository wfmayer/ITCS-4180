
public class PartTwo {
	public static void main(String[] args) {
		// Include implementation for Part 2, and create all the required classes.
	}
}


public class PartThree {
	public static void main(String[] args) {
		// Include implementation for Part 3, and create all the required classes.
	}

}
